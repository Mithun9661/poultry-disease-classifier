
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Upload, Camera, Activity, AlertTriangle, CheckCircle, Info, TrendingUp, Users, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';

function App() {
  const [selectedImage, setSelectedImage] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [activeTab, setActiveTab] = useState('classify');

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target.result);
        setAnalysisResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = () => {
    if (!selectedImage) {
      toast({
        title: "No Image Selected",
        description: "Please upload an image first to analyze.",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const mockResults = [
        {
          disease: "Newcastle Disease",
          confidence: 92.5,
          severity: "High",
          description: "A highly contagious viral infection affecting the respiratory, nervous, and digestive systems.",
          symptoms: ["Respiratory distress", "Neurological signs", "Decreased egg production", "Diarrhea"],
          treatment: "Immediate isolation, supportive care, vaccination of healthy birds",
          prevention: "Regular vaccination, biosecurity measures, quarantine new birds"
        },
        {
          disease: "Avian Influenza",
          confidence: 87.3,
          severity: "Critical",
          description: "A viral infection that can cause severe respiratory and systemic illness.",
          symptoms: ["Sudden death", "Respiratory distress", "Swollen head", "Blue discoloration"],
          treatment: "Immediate veterinary consultation, isolation, supportive therapy",
          prevention: "Vaccination, biosecurity protocols, monitoring wild bird populations"
        },
        {
          disease: "Infectious Bronchitis",
          confidence: 78.9,
          severity: "Medium",
          description: "A respiratory disease caused by coronavirus affecting chickens.",
          symptoms: ["Coughing", "Sneezing", "Nasal discharge", "Reduced egg quality"],
          treatment: "Supportive care, antibiotics for secondary infections, improved ventilation",
          prevention: "Vaccination, proper ventilation, stress reduction"
        }
      ];

      const randomResult = mockResults[Math.floor(Math.random() * mockResults.length)];
      setAnalysisResult(randomResult);
      setIsAnalyzing(false);
      
      toast({
        title: "Analysis Complete",
        description: `Disease classification completed with ${randomResult.confidence}% confidence.`
      });
    }, 3000);
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Critical': return 'text-red-500 bg-red-100';
      case 'High': return 'text-orange-500 bg-orange-100';
      case 'Medium': return 'text-yellow-500 bg-yellow-100';
      default: return 'text-green-500 bg-green-100';
    }
  };

  const mockStats = [
    { label: "Total Analyses", value: "1,247", icon: Activity, trend: "+12%" },
    { label: "Healthy Birds", value: "892", icon: CheckCircle, trend: "+8%" },
    { label: "Active Cases", value: "23", icon: AlertTriangle, trend: "-15%" },
    { label: "Farms Monitored", value: "156", icon: Users, trend: "+5%" }
  ];

  return (
    <>
      <Helmet>
        <title>PoultryAI - Advanced Disease Classification System</title>
        <meta name="description" content="AI-powered poultry disease classification system for enhanced health management and early detection." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="flex justify-center items-center mb-6">
              <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-4 rounded-2xl shadow-lg">
                <Activity className="w-12 h-12 text-white" />
              </div>
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-4">
              PoultryAI Health System
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Advanced transfer learning-based classification system for early detection and management of poultry diseases
            </p>
          </motion.div>

          {/* Stats Dashboard */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
          >
            {mockStats.map((stat, index) => (
              <div key={index} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-3 rounded-xl">
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-emerald-600 text-sm font-semibold flex items-center">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    {stat.trend}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</h3>
                <p className="text-gray-600 text-sm">{stat.label}</p>
              </div>
            ))}
          </motion.div>

          {/* Navigation Tabs */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex justify-center mb-8"
          >
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-2 shadow-lg border border-white/20">
              <div className="flex space-x-2">
                {[
                  { id: 'classify', label: 'Disease Classification', icon: Camera },
                  { id: 'dashboard', label: 'Health Dashboard', icon: Activity },
                  { id: 'reports', label: 'Reports & Analytics', icon: Calendar }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      if (tab.id !== 'classify') {
                        toast({
                          title: "🚧 Feature Coming Soon",
                          description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
                        });
                      }
                    }}
                    className={`flex items-center px-6 py-3 rounded-xl font-medium transition-all ${
                      activeTab === tab.id
                        ? 'bg-gradient-to-r from-emerald-500 to-blue-600 text-white shadow-lg'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <tab.icon className="w-5 h-5 mr-2" />
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            {/* Image Upload Section */}
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <Upload className="w-6 h-6 mr-3 text-emerald-600" />
                Image Analysis
              </h2>
              
              <div className="space-y-6">
                <div className="border-2 border-dashed border-emerald-300 rounded-2xl p-8 text-center bg-emerald-50/50">
                  {selectedImage ? (
                    <div className="space-y-4">
                      <img
                        src={selectedImage}
                        alt="Selected poultry"
                        className="max-w-full h-64 object-cover rounded-xl mx-auto shadow-lg"
                      />
                      <p className="text-emerald-600 font-medium">Image ready for analysis</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-4 rounded-2xl w-fit mx-auto">
                        <Camera className="w-12 h-12 text-white" />
                      </div>
                      <div>
                        <p className="text-lg font-medium text-gray-700 mb-2">Upload Poultry Image</p>
                        <p className="text-gray-500">Select a clear image of the bird for AI analysis</p>
                      </div>
                    </div>
                  )}
                </div>

                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                
                <div className="flex gap-4">
                  <label htmlFor="image-upload" className="flex-1">
                    <Button className="w-full bg-gradient-to-r from-emerald-500 to-blue-600 hover:from-emerald-600 hover:to-blue-700 text-white font-semibold py-3 rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105">
                      <Upload className="w-5 h-5 mr-2" />
                      Choose Image
                    </Button>
                  </label>
                  
                  <Button
                    onClick={analyzeImage}
                    disabled={!selectedImage || isAnalyzing}
                    className="flex-1 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-semibold py-3 rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:transform-none"
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Activity className="w-5 h-5 mr-2" />
                        Analyze
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            {/* Results Section */}
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <Info className="w-6 h-6 mr-3 text-blue-600" />
                Analysis Results
              </h2>

              {analysisResult ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-6"
                >
                  {/* Disease Classification */}
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-200">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold text-gray-800">{analysisResult.disease}</h3>
                      <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getSeverityColor(analysisResult.severity)}`}>
                        {analysisResult.severity}
                      </span>
                    </div>
                    
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">Confidence Level</span>
                        <span className="font-bold text-blue-600">{analysisResult.confidence}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className="bg-gradient-to-r from-blue-500 to-indigo-600 h-3 rounded-full transition-all duration-1000"
                          style={{ width: `${analysisResult.confidence}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <p className="text-gray-700">{analysisResult.description}</p>
                  </div>

                  {/* Symptoms */}
                  <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-2xl p-6 border border-orange-200">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                      <AlertTriangle className="w-5 h-5 mr-2 text-orange-600" />
                      Common Symptoms
                    </h4>
                    <ul className="space-y-2">
                      {analysisResult.symptoms.map((symptom, index) => (
                        <li key={index} className="flex items-center text-gray-700">
                          <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                          {symptom}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Treatment */}
                  <div className="bg-gradient-to-r from-emerald-50 to-green-50 rounded-2xl p-6 border border-emerald-200">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                      <CheckCircle className="w-5 h-5 mr-2 text-emerald-600" />
                      Recommended Treatment
                    </h4>
                    <p className="text-gray-700">{analysisResult.treatment}</p>
                  </div>

                  {/* Prevention */}
                  <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl p-6 border border-purple-200">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                      <Info className="w-5 h-5 mr-2 text-purple-600" />
                      Prevention Measures
                    </h4>
                    <p className="text-gray-700">{analysisResult.prevention}</p>
                  </div>
                </motion.div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gradient-to-r from-gray-400 to-gray-500 p-4 rounded-2xl w-fit mx-auto mb-4">
                    <Activity className="w-12 h-12 text-white" />
                  </div>
                  <p className="text-gray-500 text-lg">Upload and analyze an image to see detailed results</p>
                  <p className="text-gray-400 mt-2">Our AI will provide disease classification, treatment recommendations, and prevention strategies</p>
                </div>
              )}
            </div>
          </motion.div>

          {/* Additional Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            {[
              {
                title: "Real-time Monitoring",
                description: "Continuous health tracking and alert system for your poultry farm",
                icon: Activity,
                color: "from-emerald-500 to-green-600"
              },
              {
                title: "Treatment Database",
                description: "Comprehensive database of treatments and medications for various diseases",
                icon: Info,
                color: "from-blue-500 to-indigo-600"
              },
              {
                title: "Veterinary Network",
                description: "Connect with certified veterinarians for professional consultation",
                icon: Users,
                color: "from-purple-500 to-pink-600"
              }
            ].map((feature, index) => (
              <div
                key={index}
                className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20 cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-105"
                onClick={() => toast({
                  title: "🚧 Feature Coming Soon",
                  description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
                })}
              >
                <div className={`bg-gradient-to-r ${feature.color} p-3 rounded-xl w-fit mb-4`}>
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </motion.div>
        </div>
        
        <Toaster />
      </div>
    </>
  );
}

export default App;
